# Readme
## Q4 
### Parent class : Animal Class
#### Attributes:
* `attrib`:I am an animal
* `legs`:4
#### Functions:
* `animal_call()`: `print`: "Animal Call"
* `animal_fun()`: `print`: "Animal Function"
### Child class : Dog class
#### Attributes:
* `attrib`:"I am a dog"
* `legs`:4(Inherited Attribute)
#### Functions:
* `animal_call()`: `print` :  "Barking"
* `animal_fun()`:(Inherited function)
### Child class : Cat class
#### Attributes:
* `attrib`:"I am a cat"
* `legs`:4(Inherited Attribute)
#### Functions:
* `animal_call()`: `print` :  "Meow..."
* `animal_fun()`:(Inherited function)
###
The class dog inherits Animal's attribute and all its functions
The class cat inherits Animal attribute and all its functions

I have added a lot of comments in the code itself,please look at that too.