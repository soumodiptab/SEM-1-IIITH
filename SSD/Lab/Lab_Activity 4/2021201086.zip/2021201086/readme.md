# Lab Activity 4
```
├── index.html
├── readme.md
├── scripts
│   └── index.js
└── styles
    └── style.css
```
Please use index.html to start the webpage