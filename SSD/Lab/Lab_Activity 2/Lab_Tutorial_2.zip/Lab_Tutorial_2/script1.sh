#!/bin/bash
args=("$@")
echo "First->"  ${args[0]} 
echo "Second->" ${args[1]}

