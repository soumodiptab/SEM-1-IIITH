#!/bin/bash
echo "Username: $1";
echo "Age: $2";
