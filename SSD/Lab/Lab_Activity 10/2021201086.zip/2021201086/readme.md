# Readme :
please install flask_restful
```
pip install flask_restful
```