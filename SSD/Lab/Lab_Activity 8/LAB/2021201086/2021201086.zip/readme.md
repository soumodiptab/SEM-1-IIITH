# LAB ACTIVITY 8 : NODE JS
## Server Implementation
## Data : 
* data.json
## Server files:
* server.js
* service.js