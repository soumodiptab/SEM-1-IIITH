# Lord Of the Rings 
To start the webpages please open the index.html file
The CSS styling is done in the style.css
The resource images that have been used are present in img folder. 