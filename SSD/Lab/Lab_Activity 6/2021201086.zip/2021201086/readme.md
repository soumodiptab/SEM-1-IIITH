`
.
├── q1.sql
├── q2.sql
├── q3.sql
├── q4.sql
├── q5.sql
└── readme.md
`
SQL  Class Activity
